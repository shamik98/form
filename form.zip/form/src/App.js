//////////////////////////////////////////////1///////////////////////////////////////////////////
// import logo from "./logo.svg";
// import "./App.css";

//   const handleSubmit = (e) => {
//     e.preventDefault()
//     const name = document.querySelector('.Name').value;
//     const address = document.querySelector('.Address').value;
//     const age = document.querySelector('.Age').value;
//     console.log(name, address, age);
//     console.log("Name is", name );
//     console.log("Address is", address);
//     console.log("Age is", age);

// };
// const App =()=> {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//         <p>Shamik</p>
//         <form>
//           <label>
//             Enter your name:
//             <input type="text" className="Name" />
//           </label>
//         </form>

//         <form>
//           <label>
//             Enter your address:
//             <input
//               type="text"
//               className="Address"
//             />
//           </label>
//         </form>
//         <form>
//           <label>
//             Enter your age:
//             <input type="number" name="age"  className="Age" />
//           </label>
//           <input type="submit" className="Submit" onClick={handleSubmit} />
//         </form>
//       </header>
//     </div>
//   );
// }

// export default App;

//////////////////////////////////////////////2///////////////////////////////////////////////////

// import logo from "./logo.svg";
// import "./App.css";
// import React, { useState } from "react";

// const App = () => {
//   const [name, setName] = useState("");
//   const [address, setAddress] = useState("");
//   const [age, setAge] = useState("");

//   const handleSubmit = (event) => {
//     event.preventDefault();
//     console.log("Name:", name);
//     console.log("Address:", address);
//     console.log("Age:", age);
//   };

//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//         <p>{name}</p>
//         <p>{address}</p>
//         <p>{age}</p>
//         <form>
//           <label>
//             Enter your name:
//             <input
//               type="text"
//               className="Name"
//               value={name}
//               onChange={(event) => setName(event.target.value)}
//             />
//           </label>
//         </form>

//         <form>
//           <label>
//             Enter your address:
//             <input
//               type="text"
//               className="Address"
//               value={address}
//               onChange={(event) => setAddress(event.target.value)}
//             />
//           </label>
//         </form>
//         <form>
//           <label>
//             Enter your age:
//             <input
//               type="number"
//               name="age"
//               className="Age"
//               value={age}
//               onChange={(event) => setAge(event.target.value)}
//             />
//           </label>
//           <input
//             type="submit"
//             className="Submit"
//             onClick={handleSubmit}
//           />
//         </form>
//       </header>
//     </div>
//   );
// };

// export default App;

//////////////////////////////////////////////3///////////////////////////////////////////////////

import logo from "./logo.svg";
import "./App.css";
import React, { useState } from "react";

const App = () => {
  const [name, setName] = useState("");
  if (name.length > 10) {
    alert("Max character limit exceeded for name.");
  }
  const [address, setAddress] = useState("");
  const [age, setAge] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
    if (name.length > 10) {
      alert("Max character limit exceeded for name.");
    } else {
      console.log("Name:", name);
      console.log("Address:", address);
      console.log("Age:", age);
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
        <form>
          <label>
            Enter your name:
            <input
              type="text"
              className="Name"
              value={name}
              onChange={(event) => setName(event.target.value)}
            />
          </label>
          <br />
          <label>
            Enter your address:
            <input
              type="text"
              className="Address"
              value={address}
              onChange={(event) => setAddress(event.target.value)}
            />
          </label>
          <br />
          <label>
            Enter your age:
            <input
              type="number"
              name="age"
              className="Age"
              value={age}
              onChange={(event) => setAge(event.target.value)}
            />
          </label>
          <br />
          <button type="submit" className="Submit" onClick={handleSubmit}>
            Submit
          </button>
        </form>
        <p>Name: {name}</p>
        <p>Address: {address}</p>
        <p>Age: {age}</p>
      </header>
    </div>
  );
};

export default App;


//////////////////////////////////////////////4///////////////////////////////////////////////////

// import logo from "./logo.svg";
// import "./App.css";
// import React, { useState } from "react";

// const App = () => {
//   const [name, setName] = useState("");
//   const [address, setAddress] = useState("");
//   const [age, setAge] = useState("");

//   const isNameValid = name.length > 0 && name.length <= 10;
//   const isAddressValid = address.length > 0;
//   const isAgeValid = age.length > 0;

//   const handleSubmit = (event) => {
//     event.preventDefault();
//     console.log("Name:", name);
//     console.log("Address:", address);
//     console.log("Age:", age);
//   };

//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//         <form>
//           <label>
//             Enter your name:
//             <input
//               type="text"
//               className="Name"
//               value={name}
//               onChange={(event) => setName(event.target.value)}
//             />
//           </label>
//           <br />
//           <label>
//             Enter your address:
//             <input
//               type="text"
//               className="Address"
//               value={address}
//               onChange={(event) => setAddress(event.target.value)}
//               disabled={!isNameValid}
//             />
//           </label>
//           <br />
//           <label>
//             Enter your age:
//             <input
//               type="number"
//               name="age"
//               className="Age"
//               value={age}
//               onChange={(event) => setAge(event.target.value)}
//               disabled={!isAddressValid}
//             />
//           </label>
//           <br />
//           <button
//             type="submit"
//             className="Submit"
//             onClick={handleSubmit}
//             disabled={!isAgeValid}
//           >
//             Submit
//           </button>
//         </form>
//         <p>Name: {name}</p>
//         <p>Address: {address}</p>
//         <p>Age: {age}</p>
//       </header>
//     </div>
//   );
// };

// export default App;

